﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using RPG.Core;
// Modified from https://forum.unity.com/threads/ai-that-follows-the-player-if-he-is-in-range-answered.520572/ by bacchinmarco4
public class EnemyAi : MonoBehaviour 
{
    public Transform player; // changed this to Transform
    public float detectRange = 10; // this gets multiplied by itself to compare to a sqr magnitude check (instead of distance)
    public bool inRange = false;
    public float moveSpeed = 2f; // you can adjust this, of course.
    NavMeshAgent navMeshAgent;


    void Awake()
    {
        navMeshAgent = GetComponent<NavMeshAgent>();
        detectRange *= detectRange;
    }

    void Update()
    {
        // a little cheaper than 'distance'.. deleted the code to create a position from the player values.
        float distsqr = (player.position - transform.position).sqrMagnitude;

        if (distsqr <= detectRange)
        {
            inRange = true;
            // get a velocity based on the normalized direction, multiplied by move speed.
            Vector2 velocity = (player.transform.position - transform.position).normalized * moveSpeed;
            navMeshAgent.velocity = velocity;
        }
    }
}
