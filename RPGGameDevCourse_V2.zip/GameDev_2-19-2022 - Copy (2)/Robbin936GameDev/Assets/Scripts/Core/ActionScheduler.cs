using UnityEngine;

namespace RPG.Core
{
    public class ActionScheduler : MonoBehaviour
    {
        MonoBehavior currentAction;

        public void StartAction(MonoBehavior action)
        {
            print("Cancelling" + currentAction);
            currentAction = action;
        }
    }
}