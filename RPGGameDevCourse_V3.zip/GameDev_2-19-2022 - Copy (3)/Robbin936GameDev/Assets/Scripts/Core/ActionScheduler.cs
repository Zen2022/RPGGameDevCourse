using UnityEngine;

// namespace RPG.Core
// {
//     //Relocated to Mover.cs
//     // public class ActionScheduler : MonoBehaviour
//     // {
//     //     MonoBehaviour currentAction;

//     //     public void StartAction(MonoBehaviour action)
//     //     {
//     //         print("Cancelling" + currentAction);
//     //         currentAction = action;
//     //     }
//     // }
// }